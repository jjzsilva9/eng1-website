<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset_1" tilewidth="32" tileheight="32" tilecount="1104" columns="48">
 <image source="Slates [32x32px orthogonal tileset by Ivan Voirol].png" width="1536" height="736"/>
</tileset>
