<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Bus_stop" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <properties>
  <property name="Bus" value="true"/>
 </properties>
 <image source="Bus_stop.png" width="113" height="113"/>
 <tile id="3">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Bus" value=""/>
  </properties>
 </tile>
</tileset>
